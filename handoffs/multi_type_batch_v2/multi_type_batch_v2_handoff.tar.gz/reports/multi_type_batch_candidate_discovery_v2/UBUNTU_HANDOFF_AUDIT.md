# Ubuntu Multi-Type Batch V2 Handoff Audit — access blocked

Date: 2026-11-02. This is a read-only handoff status, not a production-coverage or Gateway-compatibility certification.

## Access evidence

The prior repository audit `ActiveLearning/docs/batch_runner_v2/BATCH_RUNNER_V2_B1_UBUNTU_OFFLINE_VALIDATION.md` records `ubuntu@43.160.197.84` as a previously supplied host. A read-only SSH `pwd` probe with batch authentication and strict host-key checking reached that host but returned `Permission denied (publickey,password)`. The current Windows session has no `C:\Users\clair\.ssh\config`, no visible default `.ssh` identity directory, and no running SSH agent identity. The host record may be stale; no current Ubuntu directory was inspected.

**Result: UBUNTU_ACCESS_BLOCKED.** It is unknown whether the V2 audit files have been transferred. Therefore no file is asserted missing on Ubuntu, and no dependent coverage, Gateway, Preflight or per-type runtime checks were performed.

## Local source package awaiting Ubuntu verification

The Windows V2 directory contains `screening_summary.md`, `candidate_inventory.csv`, `type_batch_summary.csv`, `proposed_batches.md`, `v1_vs_v2_comparison.md`, and 28 provisional `batch_manifests/MTV2_*.json` files. `build_discovery.py` is the local reproducibility script, not a Gateway input. The 28 manifests name 254 unique IDs; they are explicitly **not** verified Gateway manifests.

## Pending checks after access is restored

1. Locate the five named audit files and 28 manifests on the actual Ubuntu checkout; enumerate exact missing names if any. Do not synthesize replacements.
2. Reconcile all 254 IDs against actual Ubuntu Batch 001–046 manifests, receipts and later production records; distinguish never submitted, submitted/incomplete, preparation completed, formal AL completed, failed/blocked and unknown.
3. Inspect actual Gateway schema, naming/identity rules, submission and Preflight commands before proposing any executable manifest.
4. Audit per-type Evaluator, AutoConfig, target, D0 and AL registration and ID guards; separate routine onboarding from code-level blockers.
5. Only then rank the first three duplicate-free batches and give verified existing commands. No command is asserted from this Windows-only evidence.

No SPICE, D0, AL, LLM, Gateway submission, production-code edit, commit or push occurred.

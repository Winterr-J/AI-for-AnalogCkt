# V1 versus V2: admission boundary changed

Both audits inspect the same **2,504** circuit-ID/type population. V1 answered “which circuit already has enough verified physical, D0, target and AL-interface evidence to be called ready?” V2 answers “which circuit has enough basic structure to **enter** the Ubuntu onboarding pipeline?” The statuses are therefore not a quality improvement claim. No new SPICE or AL evidence was created between the audits by this task.

| V1 status | Count | V2 treatment |
|---|---:|---|
| READY_FOR_AL | 22 | All 22 become `ALREADY_TESTED`; excluded from new proposals. |
| READY_FOR_BATCH_PREPARATION | 4 | Three become `BATCH_CANDIDATE`; 0296 initially triggered a literal-VOUT check but its reviewed LC measurement mapping overrides that check, so **all four** are candidates in the final inventory. |
| NEEDS_CANARY | 2 | 0646/0648 become `BATCH_CANDIDATE`; their response measurements move to Ubuntu Preflight/Preparation, not a universal Windows prerequisite. |
| NEEDS_ADAPTER | 8 | Two structurally plausible SampleHold cells enter as candidates; six retain a named static interface/fixture concern for review. |
| BLOCKED | 12 | All become `REVIEW_NEEDED`, not automatic exclusions: the known bias, fixture or measured-gain problem is real, but V2 does not infer a fatal source-topology defect from one frozen operating condition. |
| INSUFFICIENT_EVIDENCE | 2,456 | Re-screened directly: **1,643** candidate, **198** static review, **94** source-confirmed unsuitable for the current standard subtype route, **521** OpAmp/CurrentMirror Ubuntu-coverage reconciliation. |

V1's `INSUFFICIENT_EVIDENCE` mostly meant absent real circuit-level function/D0/AL history, not missing netlists. V2 inspected the available local netlist structure and did **not** demand those downstream outputs. That is why the broad candidate count rises to **1,651** without any claim that 1,651 circuits will pass Preflight, receive meaningful targets, complete D0, or run AL. The `REVIEW_NEEDED` set has a concrete local issue, such as missing/ambiguous output or known source-backed bias/hierarchy concern. Unknown DC operation, convergence, target values, historical measurements and missing D0 were not used as exclusions.

The V2 `EXCLUDE` decisions are narrowly scoped to current subtype routes: `circuit_0246`–`0248` and `0255` are PTAT/CTAT generator or test cells, not stand-alone compensated VREF cells; the 90 `circuit_2201`–`2290` G3 LDO variants have source-audited amplifier-port shorts/merges and an incomplete digital-control model, so they cannot use the **current standard LDO** onboarding route. This is not a claim that those circuits are useless or irreparable. `circuit_0702` is a current-reference cell and remains in the CurrentMirror/coverage-reconciliation population, not relabeled as a voltage reference.

V1 proposed no executable multi-circuit production batch. V2 proposes **28 provisional initial queues containing 254 IDs**, with up to ten circuits each, to allow the existing Ubuntu process to perform the missing work. The other admitted candidates remain machine-readable in `candidate_inventory.csv` for later tranches. Existing Batch V2 AL manifests cannot be reused as Gateway submission manifests because their schema requires frozen config/D0 hashes and targets. Until the real Ubuntu Gateway schema and Batch 001–046 coverage are inspected, **none of the provisional manifests is directly submittable**.

# Initial provisional candidate batches

No manifest here is a verified Gateway or production Batch V2 manifest. Ubuntu coverage reconciliation and Gateway schema mapping precede submission. Each listed circuit passed only lenient local static screening. The initial tranche is capped at 60 per type and 10 per detected source/morphology group; other candidates remain in the CSV backlog. Structural group keys are coarse and do not certify independent topology.

## SampleHold

| Provisional batch ID | Circuit IDs | Count | Structural screen | Known uncertainty | Evaluator / Gateway route |
|---|---|---:|---|---|---|
| `MTV2_SH_001` | `circuit_0260`, `circuit_0262`, `circuit_0605`, `circuit_0606`, `circuit_0607`, `circuit_0608`, `circuit_0609`, `circuit_0610`, `circuit_0612`, `circuit_0614` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | Real-AL admission currently ID-specific (0259/0263); 0605 target unfrozen | Existing SampleHoldEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_SH_002` | `circuit_0615`, `circuit_0658` | 2 | Local netlist nonempty; basic type interface present; 2 coarse source/morphology groups | Real-AL admission currently ID-specific (0259/0263); 0605 target unfrozen | Existing SampleHoldEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |

## Oscillator

| Provisional batch ID | Circuit IDs | Count | Structural screen | Known uncertainty | Evaluator / Gateway route |
|---|---|---:|---|---|---|
| `MTV2_OSC_001` | `circuit_0277`, `circuit_0278`, `circuit_0279`, `circuit_0283`, `circuit_0284`, `circuit_0285`, `circuit_0286`, `circuit_0287`, `circuit_0288`, `circuit_0289` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | Native D0 route exists for 0279/0296/0673; ordinary AL backend binding unproven | Existing OscillatorEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_OSC_002` | `circuit_0290`, `circuit_0296`, `circuit_0298`, `circuit_0299`, `circuit_0302`, `circuit_0303`, `circuit_0304`, `circuit_0386`, `circuit_0387`, `circuit_0501` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | Native D0 route exists for 0279/0296/0673; ordinary AL backend binding unproven | Existing OscillatorEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_OSC_003` | `circuit_0502`, `circuit_0503`, `circuit_0504`, `circuit_0505`, `circuit_0673`, `circuit_0950`, `circuit_0951`, `circuit_0952`, `circuit_0953`, `circuit_0954` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | Native D0 route exists for 0279/0296/0673; ordinary AL backend binding unproven | Existing OscillatorEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_OSC_004` | `circuit_0956`, `circuit_0957`, `circuit_0958`, `circuit_0959`, `circuit_0960`, `circuit_0962`, `circuit_0963`, `circuit_0964`, `circuit_0965`, `circuit_0966` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | Native D0 route exists for 0279/0296/0673; ordinary AL backend binding unproven | Existing OscillatorEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_OSC_005` | `circuit_0967`, `circuit_0968`, `circuit_0969`, `circuit_0971`, `circuit_0973`, `circuit_0974`, `circuit_0975`, `circuit_0981`, `circuit_0983`, `circuit_0987` | 10 | Local netlist nonempty; basic type interface present; 9 coarse source/morphology groups | Native D0 route exists for 0279/0296/0673; ordinary AL backend binding unproven | Existing OscillatorEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_OSC_006` | `circuit_0989`, `circuit_0995`, `circuit_0999`, `circuit_1001`, `circuit_1005`, `circuit_1006`, `circuit_1007`, `circuit_1008`, `circuit_1010`, `circuit_1011` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | Native D0 route exists for 0279/0296/0673; ordinary AL backend binding unproven | Existing OscillatorEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |

## VoltageReference/Bandgap

| Provisional batch ID | Circuit IDs | Count | Structural screen | Known uncertainty | Evaluator / Gateway route |
|---|---|---:|---|---|---|
| `MTV2_VREF_001` | `circuit_0249`, `circuit_0488`, `circuit_1301`, `circuit_1302`, `circuit_1303`, `circuit_1304`, `circuit_1305`, `circuit_1306`, `circuit_1307`, `circuit_1308` | 10 | Local netlist nonempty; basic type interface present; 9 coarse source/morphology groups | V1 evaluator exists, but generic provider/runner admission is circuit-specific | Existing VoltageReferenceEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_VREF_002` | `circuit_1309`, `circuit_1310`, `circuit_1311`, `circuit_1312`, `circuit_1313`, `circuit_1314`, `circuit_1315`, `circuit_1316`, `circuit_1317`, `circuit_1318` | 10 | Local netlist nonempty; basic type interface present; 9 coarse source/morphology groups | V1 evaluator exists, but generic provider/runner admission is circuit-specific | Existing VoltageReferenceEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_VREF_003` | `circuit_1319`, `circuit_1320`, `circuit_1321`, `circuit_1322`, `circuit_1323`, `circuit_1324`, `circuit_1325`, `circuit_1326`, `circuit_1327`, `circuit_1328` | 10 | Local netlist nonempty; basic type interface present; 9 coarse source/morphology groups | V1 evaluator exists, but generic provider/runner admission is circuit-specific | Existing VoltageReferenceEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_VREF_004` | `circuit_1329`, `circuit_1330`, `circuit_1331`, `circuit_1332`, `circuit_1333`, `circuit_1334`, `circuit_1335`, `circuit_1336`, `circuit_1337`, `circuit_1338` | 10 | Local netlist nonempty; basic type interface present; 9 coarse source/morphology groups | V1 evaluator exists, but generic provider/runner admission is circuit-specific | Existing VoltageReferenceEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_VREF_005` | `circuit_1339`, `circuit_1340`, `circuit_1341`, `circuit_1342`, `circuit_1343`, `circuit_1344`, `circuit_1345`, `circuit_1346`, `circuit_1347`, `circuit_1348` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | V1 evaluator exists, but generic provider/runner admission is circuit-specific | Existing VoltageReferenceEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_VREF_006` | `circuit_1349`, `circuit_1350`, `circuit_1351`, `circuit_1352`, `circuit_1353`, `circuit_1354`, `circuit_1355`, `circuit_1356`, `circuit_1358`, `circuit_1359` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | V1 evaluator exists, but generic provider/runner admission is circuit-specific | Existing VoltageReferenceEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |

## SCIntegrator

| Provisional batch ID | Circuit IDs | Count | Structural screen | Known uncertainty | Evaluator / Gateway route |
|---|---|---:|---|---|---|
| `MTV2_SCI_001` | `circuit_2585`, `circuit_2662`, `circuit_2736`, `circuit_2745`, `circuit_2871`, `circuit_2873`, `circuit_2898`, `circuit_2963`, `circuit_2974`, `circuit_2997` | 10 | Local netlist nonempty; basic type interface present; 1 coarse source/morphology groups | Production fixture and AL admission currently bound to 0662/0644 | Existing SCIntegratorEvaluatorV1; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_SCI_002` | `circuit_3063`, `circuit_3099`, `circuit_3164`, `circuit_3179`, `circuit_3228`, `circuit_3247`, `circuit_3254`, `circuit_3267`, `circuit_3268`, `circuit_3271` | 10 | Local netlist nonempty; basic type interface present; 1 coarse source/morphology groups | Production fixture and AL admission currently bound to 0662/0644 | Existing SCIntegratorEvaluatorV1; map to verified Ubuntu Gateway schema after coverage reconciliation |

## SCAmplifier

| Provisional batch ID | Circuit IDs | Count | Structural screen | Known uncertainty | Evaluator / Gateway route |
|---|---|---:|---|---|---|
| `MTV2_SCA_001` | `circuit_0613`, `circuit_0651`, `circuit_0653`, `circuit_3276`, `circuit_3279`, `circuit_3287`, `circuit_3290`, `circuit_3293`, `circuit_3296`, `circuit_3297` | 10 | Local netlist nonempty; basic type interface present; 4 coarse source/morphology groups | Physical A/B fixture and guarded AL admission currently 0269-specific | Existing SCAmplifierEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_SCA_002` | `circuit_3298`, `circuit_3302`, `circuit_3309`, `circuit_3312`, `circuit_3313` | 5 | Local netlist nonempty; basic type interface present; 2 coarse source/morphology groups | Physical A/B fixture and guarded AL admission currently 0269-specific | Existing SCAmplifierEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |

## Filter

| Provisional batch ID | Circuit IDs | Count | Structural screen | Known uncertainty | Evaluator / Gateway route |
|---|---|---:|---|---|---|
| `MTV2_FIL_001` | `circuit_0627`, `circuit_0633`, `circuit_0636`, `circuit_0639`, `circuit_0640` | 5 | Local netlist nonempty; basic type interface present; 5 coarse source/morphology groups | AutoConfig currently allowlists passive 0511 LPF; active/filter mode must be mapped | Existing FilterEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |

## SCFilter

| Provisional batch ID | Circuit IDs | Count | Structural screen | Known uncertainty | Evaluator / Gateway route |
|---|---|---:|---|---|---|
| `MTV2_SCF_001` | `circuit_0646`, `circuit_0648` | 2 | Local netlist nonempty; basic type interface present; 2 coarse source/morphology groups | Physical AL backend admits reviewed 0647/0650 experiment IDs only | Existing SCFilterEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |

## Comparator

| Provisional batch ID | Circuit IDs | Count | Structural screen | Known uncertainty | Evaluator / Gateway route |
|---|---|---:|---|---|---|
| `MTV2_CMP_001` | `circuit_0495`, `circuit_0496`, `circuit_0594`, `circuit_0595`, `circuit_0596`, `circuit_0597`, `circuit_0599`, `circuit_0601`, `circuit_0602`, `circuit_0603` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | Static V1 mapping allowlists 0494/0593/0882; other outputs need semantic review | Existing ComparatorEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_CMP_002` | `circuit_0604`, `circuit_0881`, `circuit_0887`, `circuit_0888`, `circuit_0889`, `circuit_0890`, `circuit_0891`, `circuit_0892`, `circuit_0894`, `circuit_0895` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | Static V1 mapping allowlists 0494/0593/0882; other outputs need semantic review | Existing ComparatorEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_CMP_003` | `circuit_0896`, `circuit_0897`, `circuit_0898`, `circuit_0899`, `circuit_0900`, `circuit_0902`, `circuit_0903`, `circuit_0905`, `circuit_0906`, `circuit_0911` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | Static V1 mapping allowlists 0494/0593/0882; other outputs need semantic review | Existing ComparatorEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_CMP_004` | `circuit_0912`, `circuit_0913`, `circuit_0914`, `circuit_0915`, `circuit_0916`, `circuit_0917`, `circuit_0918`, `circuit_0919`, `circuit_0920`, `circuit_0921` | 10 | Local netlist nonempty; basic type interface present; 10 coarse source/morphology groups | Static V1 mapping allowlists 0494/0593/0882; other outputs need semantic review | Existing ComparatorEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |

## LDO

| Provisional batch ID | Circuit IDs | Count | Structural screen | Known uncertainty | Evaluator / Gateway route |
|---|---|---:|---|---|---|
| `MTV2_LDO_001` | `circuit_2049`, `circuit_2050`, `circuit_2059`, `circuit_2066`, `circuit_2068`, `circuit_2081`, `circuit_2088`, `circuit_2095`, `circuit_2106`, `circuit_2109` | 10 | Local netlist nonempty; basic type interface present; 1 coarse source/morphology groups | Production config/guard pins 0512; 2381 used separate guarded path | Existing LDOEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_LDO_002` | `circuit_2115`, `circuit_2128`, `circuit_2138`, `circuit_2142`, `circuit_2146`, `circuit_2150`, `circuit_2157`, `circuit_2164`, `circuit_2175`, `circuit_2184` | 10 | Local netlist nonempty; basic type interface present; 1 coarse source/morphology groups | Production config/guard pins 0512; 2381 used separate guarded path | Existing LDOEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_LDO_003` | `circuit_2291`, `circuit_2302`, `circuit_2309`, `circuit_2313`, `circuit_2325`, `circuit_2331`, `circuit_2334`, `circuit_2337`, `circuit_2348`, `circuit_2358` | 10 | Local netlist nonempty; basic type interface present; 1 coarse source/morphology groups | Production config/guard pins 0512; 2381 used separate guarded path | Existing LDOEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |
| `MTV2_LDO_004` | `circuit_2390`, `circuit_2397`, `circuit_2408`, `circuit_2423`, `circuit_2434`, `circuit_2438`, `circuit_2456`, `circuit_2459`, `circuit_2467`, `circuit_2468` | 10 | Local netlist nonempty; basic type interface present; 1 coarse source/morphology groups | Production config/guard pins 0512; 2381 used separate guarded path | Existing LDOEvaluator; map to verified Ubuntu Gateway schema after coverage reconciliation |

## Handoff conditions

All batches are planning candidates only. First reconcile each circuit against Ubuntu Batch 001–046 and any later manifests, verify the actual Gateway schema, then submit under the existing Gateway/Preflight/Preparation implementation. Profiling, config/target generation, D0, validation receipts and formal AL remain Ubuntu-only downstream stages. No execution command or resource budget is asserted here.
